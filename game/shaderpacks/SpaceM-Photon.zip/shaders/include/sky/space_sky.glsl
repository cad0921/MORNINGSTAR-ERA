#if !defined INCLUDE_SKY_SPACE_SKY
#define INCLUDE_SKY_SPACE_SKY

// MORNINGSTAR ERA (SpaceM) orbit sky: galaxy band, varied stars, distant
// planets with lit/dark sides and a ringed gas giant.
// Only used in the spacem:orbit dimension (world2, WORLD_ORBIT).
// Expects: noisetex, galaxy_sampler, sun_dir, frameTimeCounter.

#include "/include/utility/color.glsl"
#include "/include/utility/random.glsl"

// Overall tuning
const float space_galaxy_i  = 3.0;  // milky way brightness
const float space_nebula_i  = 3.5;  // coloured nebula glow on top of the band
const float space_star_i    = 1.2;  // star brightness
const float space_planet_i  = 1.8;  // brightness of the lit side of planets
const vec3  space_base      = vec3(0.0025, 0.0030, 0.0060); // deep space tint

// Galaxy orientation (tilts the milky way across the sky)
const mat3 space_galaxy_rot = mat3(
     0.8660, 0.0000, -0.5000,
     0.2500, 0.8660,  0.4330,
     0.4330, -0.5000, 0.7500
);

vec2 space_galaxy_uv(vec3 ray_dir) {
    vec3 d = space_galaxy_rot * ray_dir;
    float lon = atan(d.x, d.z);
    float lat = fast_acos(clamp(-d.y, -1.0, 1.0));
    return vec2(lon * rcp(tau) + 0.5, lat * rcp(pi));
}

float space_fbm(vec2 uv) {
    float n = 0.0;
    n += 0.500 * textureLod(noisetex, uv, 0.0).x;
    n += 0.250 * textureLod(noisetex, uv * 2.0 + 0.31, 0.0).y;
    n += 0.125 * textureLod(noisetex, uv * 4.0 + 0.57, 0.0).z;
    n += 0.125 * textureLod(noisetex, uv * 8.0 + 0.13, 0.0).w;
    return n;
}

vec3 space_galaxy(vec3 ray_dir, out float galaxy_lum) {
    vec2 uv = space_galaxy_uv(ray_dir);

    vec3 band = textureLod(galaxy_sampler, uv, 0.0).rgb;
    band = srgb_eotf_inv(band) * rec709_to_working_color;
    // Cheap wide blur of the band for a soft glow
    vec3 glow = vec3(0.0);
    const vec2 o1 = vec2(0.018, 0.0), o2 = vec2(0.0, 0.03);
    glow += textureLod(galaxy_sampler, uv + o1, 0.0).rgb;
    glow += textureLod(galaxy_sampler, uv - o1, 0.0).rgb;
    glow += textureLod(galaxy_sampler, uv + o2, 0.0).rgb;
    glow += textureLod(galaxy_sampler, uv - o2, 0.0).rgb;
    glow += textureLod(galaxy_sampler, uv + 2.2 * o1 + 1.4 * o2, 0.0).rgb;
    glow += textureLod(galaxy_sampler, uv - 2.2 * o1 - 1.4 * o2, 0.0).rgb;
    glow = srgb_eotf_inv(glow * (1.0 / 6.0)) * rec709_to_working_color;

    float lum = dot(band, luminance_weights_rec709);
    float glow_lum = dot(glow, luminance_weights_rec709);
    galaxy_lum = glow_lum;

    // Boost saturation a little so the dust lanes keep their colour
    band = max0(mix(vec3(lum), band, 1.6));

    // Coloured nebula clouds that follow the band (periodic in longitude)
    vec2 nuv = uv * vec2(4.0, 2.0);
    float n1 = space_fbm(nuv);
    float n2 = space_fbm(nuv * 2.0 + vec2(0.37, 0.71));
    float mask = 0.2 + 0.8 * smoothstep(0.004, 0.06, glow_lum);
    vec3 pink  = vec3(1.00, 0.30, 0.65);
    vec3 cyan  = vec3(0.20, 0.55, 1.00);
    vec3 gold  = vec3(1.00, 0.70, 0.35);
    vec3 neb = mix(cyan, pink, smoothstep(0.35, 0.65, n1));
    neb = mix(neb, gold, smoothstep(0.55, 0.8, n2) * 0.6);
    float neb_shape = sqr(smoothstep(0.38, 0.85, n1 * 0.6 + n2 * 0.6));
    vec3 nebula = neb * neb_shape * mask * 0.06;

    // Soft halo around the band so it glows a little
    vec3 halo = glow * vec3(0.8, 0.85, 1.2) * 1.5;

    return (band + halo) * space_galaxy_i + nebula * space_nebula_i;
}

// ---------------------------------------------------------------- stars

vec3 space_star_cell(vec2 cell, float threshold, float t_lo, float t_hi) {
    vec4 noise = hash4(cell);
    float star = linear_step(threshold, 1.0, noise.x);
    star = pow16(star);
    float temp = mix(t_lo, t_hi, sqr(noise.y));
    vec3 color = blackbody(temp);
    float twinkle = 0.35 * noise.z;
    star *= 1.0 - twinkle * cos(frameTimeCounter * (1.5 + 2.0 * noise.w) + tau * noise.w);
    return star * color;
}

vec3 space_star_field(vec2 coord, float threshold, float t_lo, float t_hi) {
    coord = abs(coord) + 33.3 * step(0.0, coord);
    vec2 i, f = modf(coord, i);
    f.x = cubic_smooth(f.x);
    f.y = cubic_smooth(f.y);
    return space_star_cell(i, threshold, t_lo, t_hi) * (1.0 - f.x) * (1.0 - f.y)
         + space_star_cell(i + vec2(1.0, 0.0), threshold, t_lo, t_hi) * f.x * (1.0 - f.y)
         + space_star_cell(i + vec2(0.0, 1.0), threshold, t_lo, t_hi) * (1.0 - f.x) * f.y
         + space_star_cell(i + vec2(1.0, 1.0), threshold, t_lo, t_hi) * f.x * f.y;
}

vec2 space_star_coord(vec3 ray_dir) {
    return ray_dir.xz * rcp(abs(ray_dir.y) + length(ray_dir.xz))
         + 41.21 * sign(ray_dir.y);
}

// A sparse layer of bright stars with a soft glow
vec3 space_bright_stars(vec3 ray_dir) {
    vec2 coord = space_star_coord(ray_dir) * 70.0;
    vec2 cell = floor(coord);
    vec2 f = coord - cell;
    vec4 h = hash4(cell + 17.0);
    if (h.x < 0.93) return vec3(0.0);

    vec2 pos = 0.3 + 0.4 * h.yz;
    float d = length(f - pos);
    float size = mix(0.6, 1.0, h.w);
    float core = exp(-sqr(d * 90.0 / size));
    float halo = exp(-d * 28.0 / size) * 0.12;
    float fade = 1.0 - smoothstep(0.22, 0.3, d);

    float temp = h.w < 0.3 ? mix(2800.0, 4200.0, h.y)
               : h.w < 0.75 ? mix(5500.0, 7500.0, h.z)
                            : mix(9000.0, 16000.0, h.y);
    float twinkle = 1.0 - 0.15 * cos(frameTimeCounter * 2.3 + 40.0 * h.z);
    float bright = (h.x - 0.93) * 60.0 * size;

    return blackbody(temp) * (core + halo) * fade * bright * twinkle;
}

vec3 space_stars(vec3 ray_dir, float galaxy_lum) {
    vec2 coord = space_star_coord(ray_dir);

    // Dense faint stars, denser inside the milky way
    float dense = clamp(galaxy_lum * 25.0, 0.0, 1.0);
    vec3 stars = space_star_field(coord * 700.0, 1.0 - 0.020 - 0.05 * dense, 3500.0, 11000.0) * 0.8;
    // Medium stars
    stars += space_star_field(coord * 300.0 + 7.7, 1.0 - 0.012, 3000.0, 14000.0) * 1.6;
    // Bright stars with glow
    stars += space_bright_stars(ray_dir);

    return stars * space_star_i;
}

// -------------------------------------------------------------- planets

// Ray (from origin) vs sphere at C with radius r. Returns distance or -1.
float space_sphere(vec3 rd, vec3 C, float r) {
    float b = dot(rd, C);
    float h = b * b - dot(C, C) + r * r;
    if (h < 0.0 || b < 0.0) return -1.0;
    return b - sqrt(h);
}

// Does a ray from p toward l hit the sphere?
bool space_shadowed(vec3 p, vec3 l, vec3 C, float r) {
    vec3 oc = C - p;
    float b = dot(oc, l);
    if (b < 0.0) return false;
    return dot(oc, oc) - b * b < r * r;
}

// Local spherical coords of normal N around spin axis
vec2 space_surface_uv(vec3 N, vec3 axis, float spin) {
    vec3 t = normalize(cross(axis, abs(axis.y) < 0.9 ? vec3(0.0, 1.0, 0.0) : vec3(1.0, 0.0, 0.0)));
    vec3 b = cross(axis, t);
    float lat = asin(clamp(dot(N, axis), -1.0, 1.0));
    float lon = atan(dot(N, b), dot(N, t)) + spin;
    return vec2(lon * rcp(tau), lat * rcp(pi) + 0.5);
}

float space_lambert(vec3 N, vec3 L) {
    float nl = dot(N, L);
    return smoothstep(-0.08, 0.35, nl) * (0.6 + 0.4 * max0(nl));
}

// Composites one planet over `sky`. type: 0 gas giant, 1 ocean world,
// 2 cratered moon, 3 teal ice dwarf
void space_planet(
    inout vec3 sky, vec3 rd, vec3 C, float r, vec3 axis, int type,
    vec3 atmo_color, float atmo_strength, bool has_ring,
    float phase, float spin_rate
) {
    // Each planet gets its own key light so it always shows a nice lit/dark
    // split (phase: 0 = fully lit, 90 = half, 140 = thin crescent)
    vec3 up_perp = normalize(vec3(0.0, 1.0, 0.0) - C * C.y + 1e-4);
    vec3 side = normalize(cross(C, vec3(0.0, 1.0, 0.0)) + 1e-4);
    vec3 light_side = normalize(side * 0.8 + up_perp * 0.6);
    float a = radians(phase);
    vec3 L = normalize(-C * cos(a) + light_side * sin(a));

    float t_body = space_sphere(rd, C, r);

    // Atmosphere halo outside the disk
    float ang = fast_acos(clamp(dot(rd, C), -1.0, 1.0));
    float rad = asin(r);
    if (t_body < 0.0 && atmo_strength > 0.0) {
        vec3 off = normalize(rd - C * dot(rd, C) + 1e-6);
        float lit = smoothstep(-0.4, 0.6, dot(off, L));
        float g = exp(-(ang - rad) / (0.06 * rad)) * lit;
        sky += atmo_color * g * atmo_strength * 0.25;
    }

    vec4 body = vec4(0.0);
    if (t_body > 0.0) {
        vec3 P = rd * t_body;
        vec3 N = (P - C) / r;
        float spin = frameTimeCounter * spin_rate;
        vec2 uv = space_surface_uv(N, axis, spin);
        vec3 albedo;

        if (type == 0) {
            // Banded gas giant with a storm
            float warp = textureLod(noisetex, uv * vec2(3.0, 2.0), 0.0).x;
            float band = textureLod(noisetex, vec2(0.13, uv.y * 1.6 + 0.08 * warp), 0.0).y;
            float fine = textureLod(noisetex, vec2(uv.x * 4.0, uv.y * 6.0 + 0.05 * warp), 0.0).z;
            vec3 cream = vec3(0.92, 0.80, 0.62);
            vec3 rust  = vec3(0.62, 0.34, 0.18);
            vec3 pale  = vec3(0.98, 0.93, 0.84);
            albedo = mix(rust, cream, smoothstep(0.3, 0.7, band));
            albedo = mix(albedo, pale, smoothstep(0.6, 0.9, fine) * 0.5);
            vec2 sp = vec2(fract(uv.x - 0.2 + 0.5) - 0.5, uv.y - 0.36) * vec2(3.0, 9.0);
            float storm = exp(-dot(sp, sp) * 8.0);
            albedo = mix(albedo, vec3(0.75, 0.25, 0.12), storm * 0.85);
        } else if (type == 4) {
            // Violet storm giant
            float warp = textureLod(noisetex, uv * vec2(3.0, 2.0) + 0.5, 0.0).x;
            float band = textureLod(noisetex, vec2(0.61, uv.y * 2.2 + 0.12 * warp), 0.0).y;
            float fine = textureLod(noisetex, vec2(uv.x * 4.0, uv.y * 7.0 + 0.06 * warp), 0.0).z;
            albedo = mix(vec3(0.30, 0.16, 0.55), vec3(0.85, 0.55, 0.95), smoothstep(0.3, 0.7, band));
            albedo = mix(albedo, vec3(0.55, 0.85, 1.0), smoothstep(0.65, 0.9, fine) * 0.45);
        } else if (type == 1) {
            // Ocean world with swirling clouds and ice caps
            float land = space_fbm(uv * vec2(2.0, 1.0) + 0.21);
            vec3 ocean = vec3(0.05, 0.18, 0.45);
            vec3 ground = vec3(0.20, 0.42, 0.25);
            albedo = mix(ocean, ground, smoothstep(0.52, 0.56, land));
            float cloud = space_fbm(uv * vec2(4.0, 2.0) + vec2(spin * 0.5, 0.0) + 0.6);
            albedo = mix(albedo, vec3(0.95), smoothstep(0.5, 0.7, cloud) * 0.85);
            float cap = smoothstep(0.82, 0.88, abs(uv.y - 0.5) * 2.0);
            albedo = mix(albedo, vec3(0.92, 0.96, 1.0), cap);
        } else if (type == 2) {
            // Grey cratered moon
            float n = space_fbm(uv * vec2(4.0, 2.0) + 0.4);
            float c = textureLod(noisetex, uv * vec2(8.0, 4.0), 0.0).w;
            albedo = vec3(0.50, 0.48, 0.52) * (0.65 + 0.6 * (n - 0.5));
            albedo *= 1.0 - 0.35 * smoothstep(0.62, 0.7, c) + 0.15 * smoothstep(0.7, 0.74, c);
        } else {
            // Teal / violet ice dwarf
            float n = space_fbm(uv * vec2(2.0, 1.0) + 0.77);
            albedo = mix(vec3(0.18, 0.55, 0.55), vec3(0.45, 0.32, 0.70), smoothstep(0.4, 0.62, n));
            albedo = mix(albedo, vec3(0.85, 0.95, 1.0), smoothstep(0.66, 0.75, n) * 0.7);
        }

        float lit = space_lambert(N, L);
        // Ring shadow on the planet
        if (has_ring) {
            float tr = dot(-N * r, axis) / dot(L, axis);
            if (tr > 0.0) {
                vec3 hit = (N * r + L * tr);
                float rr = length(hit) / r;
                if (rr > 1.35 && rr < 2.4) lit *= 0.45;
            }
        }
        float fres = pow(1.0 - max0(dot(N, -rd)), 3.0);
        vec3 color = albedo * lit * space_planet_i;
        color += albedo * 0.02;                                    // faint night side
        color += atmo_color * fres * atmo_strength * (0.1 + 0.9 * smoothstep(-0.2, 0.4, dot(N, L))) * 0.6;

        body = vec4(color, 1.0);
    }

    // Ring
    vec4 ring = vec4(0.0);
    float t_ring = -1.0;
    if (has_ring) {
        float denom = dot(rd, axis);
        if (abs(denom) > 1e-5) {
            t_ring = dot(C, axis) / denom;
            if (t_ring > 0.0) {
                vec3 Pr = rd * t_ring;
                float rr = length(Pr - C) / r;
                if (rr > 1.35 && rr < 2.4) {
                    float bands = textureLod(noisetex, vec2(rr * 0.06, 0.37), 0.0).x;
                    float fine  = textureLod(noisetex, vec2(rr * 0.35, 0.71), 0.0).y;
                    float density = smoothstep(1.35, 1.45, rr) * (1.0 - smoothstep(2.25, 2.4, rr));
                    density *= 0.5 + 0.5 * smoothstep(0.3, 0.7, bands);
                    density *= 0.8 + 0.2 * fine;
                    density *= 1.0 - 0.9 * (smoothstep(1.90, 1.93, rr) - smoothstep(1.98, 2.01, rr));
                    vec3 rcol = type == 4
                        ? mix(vec3(0.55, 0.75, 1.00), vec3(0.85, 0.70, 1.00), fine)
                        : mix(vec3(0.85, 0.62, 0.40), vec3(1.00, 0.90, 0.75), fine);
                    rcol = mix(rcol, vec3(0.55, 0.40, 0.30), smoothstep(0.55, 0.8, bands) * 0.4);
                    float rlit = 0.8 + 0.4 * abs(dot(axis, L));
                    if (space_shadowed(Pr, L, C, r)) rlit *= 0.06;
                    ring = vec4(rcol * rlit * space_planet_i, clamp(density * 0.95, 0.0, 1.0));
                } else {
                    t_ring = -1.0;
                }
            }
        }
    }

    // Composite back to front
    if (ring.a > 0.0 && body.a > 0.0 && t_ring < t_body) {
        sky = mix(sky, body.rgb, body.a);
        sky = mix(sky, ring.rgb, ring.a);
    } else {
        if (ring.a > 0.0) sky = mix(sky, ring.rgb, ring.a);
        if (body.a > 0.0) sky = mix(sky, body.rgb, body.a);
    }
}

// A shooting star every few seconds
vec3 space_meteor(vec3 rd, float seed_offset) {
    const float period = 7.0;
    float tt = frameTimeCounter / period + seed_offset;
    float id = floor(tt);
    float p = fract(tt) * 3.0;          // streak lasts a third of the period
    if (p > 1.0) return vec3(0.0);
    vec4 h = hash4(vec2(id, seed_offset * 13.0));
    if (h.w < 0.35) return vec3(0.0);

    float az = tau * h.x;
    float el = mix(0.1, 1.1, h.y);
    vec3 s = vec3(cos(az) * cos(el), sin(el), sin(az) * cos(el));
    vec3 n = normalize(cross(s, normalize(vec3(h.z - 0.5, -1.0, h.x - 0.5))));
    vec3 w = cross(n, s);
    float total = 0.35;

    float off = dot(rd, n);
    float ang = atan(dot(rd, w), dot(rd, s));
    float head = p * total;
    float tail = 0.12;
    float along = (head - ang) / tail;  // 0 at head, 1 at tail end
    if (along < 0.0 || along > 1.0 || dot(rd, s) < 0.0) return vec3(0.0);

    float width = 0.0012 * (1.0 - 0.7 * along);
    float line = exp(-sqr(off / width));
    float fade = sin(pi * p) * sqr(1.0 - along);
    return vec3(0.8, 0.9, 1.0) * line * fade * 6.0;
}

vec3 draw_space_sky(vec3 ray_dir) {
    float galaxy_lum;
    vec3 sky = space_base;
    sky += space_galaxy(ray_dir, galaxy_lum);
    sky += space_stars(ray_dir, galaxy_lum);

    // Ringed gas giant (big, half lit, turns in about 2 minutes)
    space_planet(sky, ray_dir, normalize(vec3(0.604, 0.342, 0.720)), 0.22,
        normalize(vec3(0.25, 1.0, 0.15)), 0, vec3(1.0, 0.75, 0.5), 0.8, true, 75.0, 0.05);
    // Violet storm giant with a thin blue ring
    space_planet(sky, ray_dir, normalize(vec3(-0.15, 0.70, -0.70)), 0.07,
        normalize(vec3(-0.5, 1.0, 0.3)), 4, vec3(0.8, 0.5, 1.0), 1.0, true, 110.0, 0.07);
    // Blue ocean world
    space_planet(sky, ray_dir, normalize(vec3(-0.641, 0.423, -0.641)), 0.085,
        normalize(vec3(-0.2, 1.0, 0.1)), 1, vec3(0.35, 0.65, 1.0), 1.6, false, 60.0, 0.08);
    // Cratered moon (crescent)
    space_planet(sky, ray_dir, normalize(vec3(0.814, 0.500, -0.296)), 0.045,
        vec3(0.0, 1.0, 0.0), 2, vec3(0.0), 0.0, false, 130.0, 0.03);
    // Teal ice dwarf, below the station
    space_planet(sky, ray_dir, normalize(vec3(-0.453, -0.423, 0.785)), 0.06,
        normalize(vec3(0.3, 1.0, -0.2)), 3, vec3(0.4, 1.0, 0.85), 1.0, false, 50.0, 0.06);

    // Shooting stars
    sky += space_meteor(ray_dir, 0.0);
    sky += space_meteor(ray_dir, 0.37);
    sky += space_meteor(ray_dir, 0.71);

    return sky;
}

#endif // INCLUDE_SKY_SPACE_SKY
