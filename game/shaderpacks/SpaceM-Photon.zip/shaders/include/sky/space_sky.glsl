#if !defined INCLUDE_SKY_SPACE_SKY
#define INCLUDE_SKY_SPACE_SKY

// MORNINGSTAR ERA (SpaceM) orbit sky: galaxy band, varied stars, distant
// the eight planets of the solar system (plus the Moon), lit by the sun.
// Only used in the spacem:orbit dimension (world2, WORLD_ORBIT).
// Expects: noisetex, galaxy_sampler, sun_dir, frameTimeCounter.

#include "/include/utility/color.glsl"
#include "/include/utility/random.glsl"

// Overall tuning
const float space_galaxy_i  = 1.3;  // milky way brightness
const float space_nebula_i  = 0.8;  // coloured nebula glow on top of the band
const float space_star_i    = 1.2;  // star brightness
const float space_planet_i  = 1.35;  // brightness of the lit side of planets
const vec3  space_base      = vec3(0.0025, 0.0030, 0.0060); // deep space tint
const vec3  space_sun_color = vec3(1.00, 0.66, 0.42); // the dying sun's light

// Slow, uneven breathing of the dying sun (about 0.82 .. 1.0)
float space_sun_pulse() {
    float t = frameTimeCounter;
    return 0.91 + 0.06 * sin(t * 0.21) + 0.03 * sin(t * 0.53 + 1.7);
}

// Galaxy orientation (tilts the milky way across the sky)
const mat3 space_galaxy_rot = mat3(
     0.8660, 0.0000, -0.5000,
     0.2500, 0.8660,  0.4330,
     0.4330, -0.5000, 0.7500
);

vec2 space_galaxy_uv(vec3 ray_dir) {
    vec3 d = space_galaxy_rot * ray_dir;
    float lon = atan(d.x, d.z);
    float lat = fast_acos(clamp(-d.y, -1.0, 1.0));
    return vec2(lon * rcp(tau) + 0.5, lat * rcp(pi));
}

float space_fbm(vec2 uv) {
    float n = 0.0;
    n += 0.500 * textureLod(noisetex, uv, 0.0).x;
    n += 0.250 * textureLod(noisetex, uv * 2.0 + 0.31, 0.0).y;
    n += 0.125 * textureLod(noisetex, uv * 4.0 + 0.57, 0.0).z;
    n += 0.125 * textureLod(noisetex, uv * 8.0 + 0.13, 0.0).w;
    return n;
}

// Noise on the sky sphere without pole pinching (triplanar blend)
float space_sky_noise(vec3 d, float scale, vec2 shift) {
    vec3 w = pow(abs(d), vec3(4.0));
    w /= w.x + w.y + w.z;
    float n = 0.0;
    for (int i = 0; i < 2; ++i) {
        float k = scale * (i == 0 ? 1.0 : 2.3);
        float a = i == 0 ? 0.65 : 0.35;
        n += a * (w.x * textureLod(noisetex, d.yz * k + shift, 0.0).x
                + w.y * textureLod(noisetex, d.zx * k + shift + 0.31, 0.0).x
                + w.z * textureLod(noisetex, d.xy * k + shift + 0.57, 0.0).x);
    }
    return n;
}

vec3 space_galaxy(vec3 ray_dir, out float galaxy_lum) {
    vec2 uv = space_galaxy_uv(ray_dir);

    vec3 band = textureLod(galaxy_sampler, uv, 0.0).rgb;
    band = srgb_eotf_inv(band) * rec709_to_working_color;
    // Cheap wide blur of the band for a soft glow
    vec3 glow = vec3(0.0);
    const vec2 o1 = vec2(0.018, 0.0), o2 = vec2(0.0, 0.03);
    glow += textureLod(galaxy_sampler, uv + o1, 0.0).rgb;
    glow += textureLod(galaxy_sampler, uv - o1, 0.0).rgb;
    glow += textureLod(galaxy_sampler, uv + o2, 0.0).rgb;
    glow += textureLod(galaxy_sampler, uv - o2, 0.0).rgb;
    glow += textureLod(galaxy_sampler, uv + 2.2 * o1 + 1.4 * o2, 0.0).rgb;
    glow += textureLod(galaxy_sampler, uv - 2.2 * o1 - 1.4 * o2, 0.0).rgb;
    glow = srgb_eotf_inv(glow * (1.0 / 6.0)) * rec709_to_working_color;

    // The photo panorama pinches into radial streaks at its poles. Near a
    // pole, replace it with a blur taken around the view direction in 3D,
    // which averages across the streaks and joins smoothly with the rest.
    vec3 gd = space_galaxy_rot * ray_dir;
    float pole = 1.0 - smoothstep(0.90, 0.975, abs(gd.y));
    if (pole < 1.0) {
        vec3 t1 = normalize(cross(ray_dir, vec3(0.0, 0.0, 1.0)) + 1e-4);
        vec3 t2 = cross(ray_dir, t1);
        vec3 fill = vec3(0.0);
        for (int i = 0; i < 12; ++i) {
            float th = float(i) * (tau / 12.0);
            float rr = (i % 2 == 0) ? 0.07 : 0.14;
            vec3 dd = normalize(ray_dir + rr * (cos(th) * t1 + sin(th) * t2));
            fill += textureLod(galaxy_sampler, space_galaxy_uv(dd), 0.0).rgb;
        }
        fill = srgb_eotf_inv(fill * (1.0 / 12.0)) * rec709_to_working_color;
        band = mix(fill, band, pole);
        glow = mix(fill, glow, pole);
    }

    float lum = dot(band, luminance_weights_rec709);
    float glow_lum = dot(glow, luminance_weights_rec709);
    galaxy_lum = glow_lum;

    // Boost saturation a little so the dust lanes keep their colour
    band = max0(mix(vec3(lum), band, 1.6));

    // Coloured nebula clouds that follow the band (periodic in longitude)
    float n1 = space_sky_noise(ray_dir, 0.35, vec2(0.0));
    float n2 = space_sky_noise(ray_dir, 0.7, vec2(0.37, 0.71));
    float mask = smoothstep(0.004, 0.06, glow_lum);
    vec3 pink  = vec3(1.00, 0.30, 0.65);
    vec3 cyan  = vec3(0.20, 0.55, 1.00);
    vec3 gold  = vec3(1.00, 0.70, 0.35);
    vec3 neb = mix(cyan, pink, smoothstep(0.35, 0.65, n1));
    neb = mix(neb, gold, smoothstep(0.55, 0.8, n2) * 0.6);
    float neb_shape = sqr(smoothstep(0.38, 0.85, n1 * 0.6 + n2 * 0.6));
    vec3 nebula = neb * neb_shape * mask * 0.06;

    // Soft halo around the band so it glows a little
    vec3 halo = glow * vec3(0.8, 0.85, 1.2) * 0.6;

    return (band + halo) * space_galaxy_i + nebula * space_nebula_i;
}

// ---------------------------------------------------------------- stars

vec3 space_star_cell(vec2 cell, float threshold, float t_lo, float t_hi) {
    vec4 noise = hash4(cell);
    float star = linear_step(threshold, 1.0, noise.x);
    star = pow16(star);
    float temp = mix(t_lo, t_hi, sqr(noise.y));
    vec3 color = blackbody(temp);
    float twinkle = 0.35 * noise.z;
    star *= 1.0 - twinkle * cos(frameTimeCounter * (1.5 + 2.0 * noise.w) + tau * noise.w);
    return star * color;
}

vec3 space_star_field(vec2 coord, float threshold, float t_lo, float t_hi) {
    coord = abs(coord) + 33.3 * step(0.0, coord);
    vec2 i, f = modf(coord, i);
    f.x = cubic_smooth(f.x);
    f.y = cubic_smooth(f.y);
    return space_star_cell(i, threshold, t_lo, t_hi) * (1.0 - f.x) * (1.0 - f.y)
         + space_star_cell(i + vec2(1.0, 0.0), threshold, t_lo, t_hi) * f.x * (1.0 - f.y)
         + space_star_cell(i + vec2(0.0, 1.0), threshold, t_lo, t_hi) * (1.0 - f.x) * f.y
         + space_star_cell(i + vec2(1.0, 1.0), threshold, t_lo, t_hi) * f.x * f.y;
}

vec2 space_star_coord(vec3 ray_dir) {
    return ray_dir.xz * rcp(abs(ray_dir.y) + length(ray_dir.xz))
         + 41.21 * sign(ray_dir.y);
}

// A sparse layer of bright stars with a soft glow
vec3 space_bright_stars(vec3 ray_dir) {
    vec2 coord = space_star_coord(ray_dir) * 70.0;
    vec2 cell = floor(coord);
    vec2 f = coord - cell;
    vec4 h = hash4(cell + 17.0);
    if (h.x < 0.93) return vec3(0.0);

    vec2 pos = 0.3 + 0.4 * h.yz;
    float d = length(f - pos);
    float size = mix(0.6, 1.0, h.w);
    float core = exp(-sqr(d * 90.0 / size));
    float halo = exp(-d * 28.0 / size) * 0.12;
    float fade = 1.0 - smoothstep(0.22, 0.3, d);

    float temp = h.w < 0.3 ? mix(2800.0, 4200.0, h.y)
               : h.w < 0.75 ? mix(5500.0, 7500.0, h.z)
                            : mix(9000.0, 16000.0, h.y);
    float twinkle = 1.0 - 0.15 * cos(frameTimeCounter * 2.3 + 40.0 * h.z);
    float bright = (h.x - 0.93) * 60.0 * size;

    return blackbody(temp) * (core + halo) * fade * bright * twinkle;
}

vec3 space_stars(vec3 ray_dir, float galaxy_lum) {
    vec2 coord = space_star_coord(ray_dir);

    // Dense faint stars, denser inside the milky way
    float dense = clamp(galaxy_lum * 25.0, 0.0, 1.0);
    vec3 stars = space_star_field(coord * 700.0, 1.0 - 0.020 - 0.05 * dense, 3500.0, 11000.0) * 0.8;
    // Medium stars
    stars += space_star_field(coord * 300.0 + 7.7, 1.0 - 0.012, 3000.0, 14000.0) * 1.6;
    // Bright stars with glow
    stars += space_bright_stars(ray_dir);

    return stars * space_star_i;
}

// -------------------------------------------------------------- planets

// Ray (from origin) vs sphere at C with radius r. Returns distance or -1.
float space_sphere(vec3 rd, vec3 C, float r) {
    float b = dot(rd, C);
    float h = b * b - dot(C, C) + r * r;
    if (h < 0.0 || b < 0.0) return -1.0;
    return b - sqrt(h);
}

// Does a ray from p toward l hit the sphere?
bool space_shadowed(vec3 p, vec3 l, vec3 C, float r) {
    vec3 oc = C - p;
    float b = dot(oc, l);
    if (b < 0.0) return false;
    return dot(oc, oc) - b * b < r * r;
}

// Local spherical coords of normal N around spin axis
vec2 space_surface_uv(vec3 N, vec3 axis, float spin) {
    vec3 t = normalize(cross(axis, abs(axis.y) < 0.9 ? vec3(0.0, 1.0, 0.0) : vec3(1.0, 0.0, 0.0)));
    vec3 b = cross(axis, t);
    float lat = asin(clamp(dot(N, axis), -1.0, 1.0));
    float lon = atan(dot(N, b), dot(N, t)) + spin;
    return vec2(lon * rcp(tau), lat * rcp(pi) + 0.5);
}

float space_lambert(vec3 N, vec3 L) {
    float nl = dot(N, L);
    return smoothstep(-0.08, 0.35, nl) * (0.6 + 0.4 * max0(nl));
}

// Solar system bodies (dramatic, not to scale)
#define SP_MERCURY 0
#define SP_VENUS   1
#define SP_EARTH   2
#define SP_MOON    3
#define SP_MARS    4
#define SP_JUPITER 5
#define SP_SATURN  6
#define SP_URANUS  7
#define SP_NEPTUNE 8

// Spin axis that shows the ring/poles opened by `open_deg` toward the viewer,
// rolled by `roll_deg` around the view direction.
vec3 space_axis(vec3 C, float open_deg, float roll_deg) {
    vec3 up_perp = normalize(vec3(0.0, 1.0, 0.0) - C * C.y + 1e-4);
    vec3 side = normalize(cross(C, up_perp));
    float o = radians(open_deg), p = radians(roll_deg);
    return normalize(-C * sin(o) + (up_perp * cos(p) + side * sin(p)) * cos(o));
}

// Light from the real sun, but never more than ~115 degrees of phase so every
// planet keeps a readable lit side.
vec3 space_planet_light(vec3 C) {
    vec3 V = -C;
    vec3 L = normalize(sun_dir);
    float c = dot(V, L);
    const float c_min = -0.42;
    if (c < c_min) L = normalize(L + V * (c_min - c) * 2.2);
    return L;
}

vec3 space_planet_albedo(int type, vec2 uv, float spin, float lit_amount, out vec3 emission) {
    emission = vec3(0.0);
    float lat = uv.y - 0.5; // -0.5 .. 0.5
    if (type == SP_MERCURY || type == SP_MOON) {
        float n = space_fbm(uv * vec2(4.0, 2.0) + (type == SP_MOON ? 0.9 : 0.4));
        float c = textureLod(noisetex, uv * vec2(9.0, 4.5) + 0.2, 0.0).w;
        vec3 base = type == SP_MOON ? vec3(0.62, 0.62, 0.60) : vec3(0.55, 0.50, 0.46);
        vec3 a = base * (0.7 + 0.6 * (n - 0.5));
        if (type == SP_MOON) {
            float maria = space_fbm(uv * vec2(1.5, 1.0) + 2.3);
            a = mix(a, vec3(0.30, 0.30, 0.32), smoothstep(0.52, 0.6, maria) * 0.8);
        }
        a *= 1.0 - 0.35 * smoothstep(0.62, 0.7, c) + 0.2 * smoothstep(0.7, 0.73, c);
        return a;
    }
    if (type == SP_VENUS) {
        float warp = textureLod(noisetex, uv * vec2(3.0, 2.0) + 0.3, 0.0).x;
        float swirl = textureLod(noisetex, vec2(uv.x * 2.0 + 0.4 * lat + 0.1 * warp, uv.y * 3.0), 0.0).y;
        vec3 a = mix(vec3(0.86, 0.74, 0.50), vec3(1.00, 0.95, 0.80), smoothstep(0.3, 0.75, swirl));
        return a;
    }
    if (type == SP_EARTH) {
        // Story v0.3: the Watcher net "switched Earth off". The whole planet is
        // covered in a grey-white silence; only faint shapes of the old
        // continents show through, no clouds move and no city lights remain.
        float land = space_fbm(uv * vec2(2.2, 1.1) + 0.21);
        float detail = space_fbm(uv * vec2(7.0, 3.5) + 1.7);
        bool is_land = land + 0.15 * (detail - 0.5) > 0.54;
        vec3 sea = mix(vec3(0.60, 0.62, 0.66), vec3(0.68, 0.70, 0.73), detail);
        vec3 ground = mix(vec3(0.78, 0.78, 0.79), vec3(0.88, 0.88, 0.89), detail);
        vec3 a = is_land ? ground : sea;
        // Soft streaks of the silence, like frost spreading over glass
        float streak = space_fbm(uv * vec2(12.0, 5.0) + 3.1);
        a = mix(a, vec3(0.93, 0.93, 0.94), smoothstep(0.55, 0.75, streak) * 0.6);
        emission = vec3(0.0);
        return a;
    }
    if (type == SP_MARS) {
        float n = space_fbm(uv * vec2(2.5, 1.25) + 3.1);
        float d = space_fbm(uv * vec2(6.0, 3.0) + 0.8);
        vec3 a = mix(vec3(0.70, 0.30, 0.13), vec3(0.85, 0.48, 0.25), d);
        a = mix(a, vec3(0.32, 0.14, 0.08), smoothstep(0.55, 0.65, n) * 0.8);
        float cap = smoothstep(0.84, 0.9, abs(lat) * 2.0);
        return mix(a, vec3(0.95, 0.93, 0.90), cap);
    }
    if (type == SP_JUPITER) {
        float warp = textureLod(noisetex, uv * vec2(4.0, 2.0), 0.0).x;
        float y = uv.y + 0.012 * (warp - 0.5);
        float bands = sin(y * pi * 15.0) * 0.5 + 0.5;
        float wobble = textureLod(noisetex, vec2(uv.x * 3.0, y * 8.0), 0.0).z;
        vec3 cream = vec3(0.94, 0.86, 0.70);
        vec3 tanc  = vec3(0.72, 0.50, 0.32);
        vec3 brown = vec3(0.50, 0.30, 0.18);
        vec3 a = mix(tanc, cream, smoothstep(0.35, 0.65, bands));
        a = mix(a, brown, smoothstep(0.75, 0.95, 1.0 - bands) * 0.5 * (0.5 + wobble));
        a = mix(a, cream, smoothstep(0.6, 0.85, wobble) * 0.25);
        // Great Red Spot in the southern hemisphere
        vec2 sp = vec2(fract(uv.x - 0.15) - 0.5, (uv.y - 0.36)) * vec2(5.0, 11.0);
        float spot = exp(-dot(sp, sp) * 3.0);
        float rim = exp(-sqr(length(sp) - 0.55) * 30.0);
        a = mix(a, vec3(0.92, 0.82, 0.68), rim * 0.4);
        a = mix(a, vec3(0.78, 0.30, 0.16), spot * 0.9);
        return a;
    }
    if (type == SP_SATURN) {
        float warp = textureLod(noisetex, uv * vec2(3.0, 2.0) + 0.7, 0.0).x;
        float bands = sin((uv.y + 0.006 * warp) * pi * 11.0) * 0.5 + 0.5;
        vec3 a = mix(vec3(0.82, 0.70, 0.46), vec3(0.96, 0.89, 0.70), smoothstep(0.3, 0.7, bands));
        a = mix(a, vec3(0.70, 0.66, 0.55), smoothstep(0.82, 0.9, abs(lat) * 2.0) * 0.6);
        return a;
    }
    if (type == SP_URANUS) {
        float b = textureLod(noisetex, vec2(0.37, uv.y * 3.0), 0.0).y;
        vec3 a = mix(vec3(0.58, 0.84, 0.86), vec3(0.68, 0.90, 0.92), b * 0.6);
        return mix(a, vec3(0.80, 0.95, 0.96), smoothstep(0.6, 0.9, abs(lat) * 2.0) * 0.5);
    }
    // Neptune
    float warp = textureLod(noisetex, uv * vec2(3.0, 2.0) + 0.2, 0.0).x;
    float bands = sin((uv.y + 0.01 * warp) * pi * 9.0) * 0.5 + 0.5;
    vec3 a = mix(vec3(0.12, 0.26, 0.75), vec3(0.22, 0.42, 0.92), bands);
    vec2 sp = vec2(fract(uv.x - 0.6) - 0.5, uv.y - 0.40) * vec2(5.0, 12.0);
    a = mix(a, vec3(0.05, 0.10, 0.35), exp(-dot(sp, sp) * 3.0) * 0.8);
    float streak = textureLod(noisetex, vec2(uv.x * 2.0, uv.y * 20.0), 0.0).z;
    a = mix(a, vec3(0.92, 0.95, 1.0), smoothstep(0.82, 0.92, streak) * 0.6);
    return a;
}

// ring = (inner, outer, opacity) in planet radii; outer == 0 means no ring
void space_planet(
    inout vec3 sky, vec3 rd, vec3 C, float r, vec3 axis, int type,
    vec3 atmo_color, float atmo_strength, vec3 ring, float spin_rate
) {
    vec3 L = space_planet_light(C);
    bool has_ring = ring.y > 0.0;
    float spin = frameTimeCounter * spin_rate;

    float t_body = space_sphere(rd, C, r);

    // Atmosphere halo outside the disk
    float ang = fast_acos(clamp(dot(rd, C), -1.0, 1.0));
    float rad = asin(r);
    if (t_body < 0.0 && atmo_strength > 0.0) {
        vec3 off = normalize(rd - C * dot(rd, C) + 1e-6);
        float lit = smoothstep(-0.4, 0.6, dot(off, L));
        float g = exp(-(ang - rad) / (0.05 * rad)) * lit;
        sky += atmo_color * g * atmo_strength * 0.25;
    }

    // Planets block the stars and galaxy behind them
    vec4 body = vec4(0.0);
    if (t_body > 0.0) {
        vec3 P = rd * t_body;
        vec3 N = (P - C) / r;
        vec2 uv = space_surface_uv(N, axis, spin);
        float lit = space_lambert(N, L);
        vec3 emission;
        vec3 albedo = space_planet_albedo(type, uv, spin, lit, emission);

        if (has_ring) {
            float tr = dot(-N * r, axis) / dot(L, axis);
            if (tr > 0.0) {
                float rr = length(N * r + L * tr) / r;
                if (rr > ring.x && rr < ring.y) lit *= 1.0 - 0.6 * ring.z;
            }
        }
        float fres = pow(1.0 - max0(dot(N, -rd)), 3.0);
        vec3 color = albedo * lit * space_planet_i * space_sun_color * space_sun_pulse();
        color += albedo * 0.012;                                   // faint night side
        color += emission;
        color += atmo_color * fres * atmo_strength * (0.1 + 0.9 * smoothstep(-0.2, 0.4, dot(N, L))) * 0.6;

        // Soft limb so the edge is not razor sharp
        float edge = 1.0 - smoothstep(rad * 0.985, rad, ang);
        body = vec4(color, edge);
    }

    vec4 ring_c = vec4(0.0);
    float t_ring = -1.0;
    if (has_ring) {
        float denom = dot(rd, axis);
        if (abs(denom) > 1e-5) {
            t_ring = dot(C, axis) / denom;
            if (t_ring > 0.0) {
                vec3 Pr = rd * t_ring;
                float rr = length(Pr - C) / r;
                if (rr > ring.x && rr < ring.y) {
                    float x = (rr - ring.x) / (ring.y - ring.x); // 0 inner .. 1 outer
                    float fine = textureLod(noisetex, vec2(rr * 0.35, 0.71), 0.0).y;
                    float bands = textureLod(noisetex, vec2(rr * 0.06, 0.37), 0.0).x;
                    float density = smoothstep(0.0, 0.06, x) * (1.0 - smoothstep(0.92, 1.0, x));
                    density *= 0.6 + 0.4 * smoothstep(0.3, 0.7, bands);
                    density *= 0.8 + 0.2 * fine;
                    vec3 rcol;
                    if (type == SP_SATURN) {
                        // C ring (faint) / B ring (bright) / Cassini gap / A ring
                        density *= mix(0.35, 1.0, smoothstep(0.18, 0.25, x));
                        density *= 1.0 - 0.92 * (smoothstep(0.60, 0.62, x) - smoothstep(0.67, 0.69, x));
                        density *= 1.0 - 0.5 * (smoothstep(0.88, 0.89, x) - smoothstep(0.90, 0.91, x));
                        rcol = mix(vec3(0.80, 0.68, 0.50), vec3(0.98, 0.92, 0.78), fine);
                    } else {
                        rcol = vec3(0.70, 0.80, 0.85);
                    }
                    float rlit = 0.75 + 0.35 * abs(dot(axis, L));
                    if (space_shadowed(Pr, L, C, r)) rlit *= 0.06;
                    ring_c = vec4(rcol * rlit * space_planet_i * space_sun_color, clamp(density * ring.z, 0.0, 1.0));
                } else {
                    t_ring = -1.0;
                }
            }
        }
    }

    // Composite back to front
    if (ring_c.a > 0.0 && body.a > 0.0 && t_ring < t_body) {
        sky = mix(sky, body.rgb, body.a);
        sky = mix(sky, ring_c.rgb, ring_c.a);
    } else {
        if (ring_c.a > 0.0) sky = mix(sky, ring_c.rgb, ring_c.a);
        if (body.a > 0.0) sky = mix(sky, body.rgb, body.a);
    }
}

// A shooting star every few seconds
vec3 space_meteor(vec3 rd, float seed_offset) {
    const float period = 7.0;
    float tt = frameTimeCounter / period + seed_offset;
    float id = floor(tt);
    float p = fract(tt) * 3.0;          // streak lasts a third of the period
    if (p > 1.0) return vec3(0.0);
    vec4 h = hash4(vec2(id, seed_offset * 13.0));
    if (h.w < 0.35) return vec3(0.0);

    float az = tau * h.x;
    float el = mix(0.1, 1.1, h.y);
    vec3 s = vec3(cos(az) * cos(el), sin(el), sin(az) * cos(el));
    vec3 n = normalize(cross(s, normalize(vec3(h.z - 0.5, -1.0, h.x - 0.5))));
    vec3 w = cross(n, s);
    float total = 0.35;

    float off = dot(rd, n);
    float ang = atan(dot(rd, w), dot(rd, s));
    float head = p * total;
    float tail = 0.12;
    float along = (head - ang) / tail;  // 0 at head, 1 at tail end
    if (along < 0.0 || along > 1.0 || dot(rd, s) < 0.0) return vec3(0.0);

    float width = 0.0012 * (1.0 - 0.7 * along);
    float line = exp(-sqr(off / width));
    float fade = sin(pi * p) * sqr(1.0 - along);
    return vec3(0.8, 0.9, 1.0) * line * fade * 6.0;
}

// Placement: the orbit dimension has a fixed time, and the sun path (any time
// of day) is the great circle tilted by sunPathRotation = -35 deg, whose plane
// normal is (0, -0.574, 0.819). Every body sits at least 35 deg away from that
// circle so the sun can never sit on top of a planet.
// Clean white sun: small disc and a soft glow (replaces Photon's orange
// swirling End flare, which looked like brown smoke around the sun).
// Story: the sun is dying. It is dimmer and redder than it should be, its
// face is blotched with dark spots and its light slowly breathes (unstable).
vec3 space_sun(vec3 ray_dir) {
    float r = fast_acos(clamp(dot(ray_dir, sun_dir), -1.0, 1.0));
    float edge = max0(sun_angular_radius - r) / sun_angular_radius;
    float disk = r < sun_angular_radius ? pow(1.0 - sqr(1.0 - edge), 0.5) : 0.0;
    vec3 c = vec3(0.0);
    if (disk > 0.0) {
        // Spots: noise in the sun's own disc coordinates, drifting slowly
        vec3 t1 = normalize(cross(sun_dir, vec3(0.0, 1.0, 0.001)));
        vec3 t2 = cross(sun_dir, t1);
        vec2 q = vec2(dot(ray_dir, t1), dot(ray_dir, t2)) / sun_angular_radius;
        float n = space_fbm(q * 0.18 + vec2(0.003 * frameTimeCounter, 0.21));
        float spots = smoothstep(0.50, 0.62, n);
        vec3 face = mix(vec3(1.00, 0.62, 0.36), vec3(0.45, 0.16, 0.08), spots * 0.85);
        face = mix(face, vec3(0.70, 0.30, 0.15), sqr(1.0 - edge)); // reddish limb
        c = face * rcp(sun_solid_angle) * disk * 0.35;
    }
    c += space_sun_color * (0.7 * exp(-r * 55.0) + 0.02 * exp(-r * 9.0));
    return c * space_sun_pulse();
}

vec3 draw_space_sky(vec3 ray_dir) {
    float galaxy_lum;
    vec3 sky = space_base;
    sky += space_galaxy(ray_dir, galaxy_lum);
    sky += space_stars(ray_dir, galaxy_lum);

    vec3 earth_dir = normalize(vec3(-0.383, 0.233, -0.894));
    vec3 moon_dir = normalize(vec3(-0.445, 0.295, -0.846));

    // Far / small first, near / big last (they never overlap, but keep it tidy)
    // Mercury: small grey, near Venus
    space_planet(sky, ray_dir, normalize(vec3(0.452, 0.882, -0.134)), 0.014,
        space_axis(normalize(vec3(0.452, 0.882, -0.134)), 5.0, 0.0), SP_MERCURY,
        vec3(0.0), 0.0, vec3(0.0), 0.02);
    // Venus: bright cream, thick yellow haze
    space_planet(sky, ray_dir, normalize(vec3(0.644, 0.688, -0.335)), 0.034,
        space_axis(normalize(vec3(0.644, 0.688, -0.335)), 5.0, 0.0), SP_VENUS,
        vec3(1.0, 0.85, 0.55), 1.4, vec3(0.0), 0.01);
    // Mars: rusty red, white polar caps, thin pink air
    space_planet(sky, ray_dir, normalize(vec3(0.583, 0.217, -0.783)), 0.024,
        space_axis(normalize(vec3(0.583, 0.217, -0.783)), 20.0, 10.0), SP_MARS,
        vec3(1.0, 0.55, 0.45), 0.5, vec3(0.0), 0.05);
    // Neptune: deep blue with a dark spot, low in the south-west
    space_planet(sky, ray_dir, normalize(vec3(-0.539, -0.631, 0.558)), 0.032,
        space_axis(normalize(vec3(-0.539, -0.631, 0.558)), 25.0, 15.0), SP_NEPTUNE,
        vec3(0.35, 0.55, 1.0), 1.2, vec3(0.0), 0.06);
    // Uranus: pale cyan tipped on its side, faint thin ring, below the horizon
    space_planet(sky, ray_dir, normalize(vec3(0.324, -0.297, 0.898)), 0.036,
        space_axis(normalize(vec3(0.324, -0.297, 0.898)), 30.0, 82.0), SP_URANUS,
        vec3(0.6, 0.9, 0.95), 1.0, vec3(1.6, 2.0, 0.35), 0.04);
    // The prologue scene (spacem:prologue, x >= 30000) shows its own Earth
    // (an item display that turns from blue to grey), so skip Earth and the Moon there.
    bool sp_prologue = cameraPosition.x > 29000.0;
    // The Moon, next to Earth
    if (!sp_prologue)
    space_planet(sky, ray_dir, moon_dir, 0.012,
        space_axis(moon_dir, 5.0, 0.0), SP_MOON,
        vec3(0.0), 0.0, vec3(0.0), 0.01);
    // Earth after the silence: grey-white, no lights (story v0.3)
    if (!sp_prologue)
    space_planet(sky, ray_dir, earth_dir, 0.052,
        space_axis(earth_dir, 23.0, -15.0), SP_EARTH,
        vec3(0.80, 0.82, 0.86), 0.6, vec3(0.0), 0.04);
    // Saturn: golden bands and wide bright rings
    vec3 saturn_dir = normalize(vec3(-0.612, 0.695, -0.376));
    space_planet(sky, ray_dir, saturn_dir, 0.070,
        space_axis(saturn_dir, 24.0, -18.0), SP_SATURN,
        vec3(1.0, 0.85, 0.6), 0.5, vec3(1.25, 2.30, 0.95), 0.06);
    // Jupiter: the biggest, striped, Great Red Spot
    vec3 jupiter_dir = normalize(vec3(0.174, 0.565, -0.807));
    space_planet(sky, ray_dir, jupiter_dir, 0.125,
        space_axis(jupiter_dir, 4.0, 5.0), SP_JUPITER,
        vec3(1.0, 0.80, 0.6), 0.6, vec3(0.0), 0.03);

    // Shooting stars
    sky += space_meteor(ray_dir, 0.0);
    sky += space_meteor(ray_dir, 0.37);
    sky += space_meteor(ray_dir, 0.71);

    return sky;
}

#endif // INCLUDE_SKY_SPACE_SKY
